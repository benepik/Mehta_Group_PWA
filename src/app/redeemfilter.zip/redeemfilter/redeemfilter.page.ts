import { Component, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiservicesService } from '../provider/apiservices.service';
import { DataTransferService } from '../services/data-transfer.service';
import { LocalStorageService } from '../services/local-storage.service';
import { URLS, APP_CONFIG } from '../../../src/assets/constant';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Location } from '@angular/common';
@Component({
  selector: 'app-redeemfilter',
  templateUrl: './redeemfilter.page.html',
  styleUrls: ['./redeemfilter.page.scss'],
})
export class RedeemfilterPage implements OnInit {

  Alldata: any;
  selecteddata: any;
  branddata: any;
  selectedindex: any;
  changecolorcheck: any=0;
  applydataarr: any;
  filterData: any;


  clickcolor:boolean=true;
  clickcolor2:boolean=false;
  showdata:boolean=false;
  todayAccStatementRespo:any;
  todayListResult:any;
  allListResult:any;
  brandCategoryData:any;
  value:number=0;
  todayBrandDetail:any;
  filterArray:any;
  showFilterDiv:boolean = false;
  showCheckRadio:any;
  errorMessage:string="";
  myInfiniteScroll:any;
  myinfiniteScrollCall:boolean=false;
  tabType:any;
  creditType:any;
  errorImage:any;
  constructor(private router:Router,private storageService:LocalStorageService,private zone:NgZone,private location:Location,
    private apiservices:ApiservicesService,private sendData:DataTransferService,private transfer:FileTransfer,private file:File) {
    this.Alldata=this.sendData.myParam;
    this.filterData=this.Alldata.filter_arr_v2;
    console.log("this.filterData",this.filterData);
    this.branddata=this.filterData[0];
    this.applydataarr=this.filterData[0].filter_options;
   }
   applydata(applydata,i){
    this.selectedindex=undefined;
     this.changecolorcheck=i;
     this.branddata=applydata;
this.applydataarr=applydata.filter_options;
   }
   select(selecteddata,j){
this.selectedindex=j;
this.selecteddata=selecteddata;
   }
  ngOnInit() {
  }

  todayAccountStatementList(){
    this.zone.run(()=>{
      console.log("brand category api function==");
      let apiKey={
        "brand_id":"",
        "value":this.value,
        "tab_type":'All', // Today, All
        "filter":this.creditType,
        "filter_select_value":this.branddata.auto_id,
        "filter_send_value":this.branddata.send_value,
        "filter_value":this.selecteddata.auto_id
      };
      console.log("brand category Acc Statement api keys==", apiKey);
      this.apiservices.discountingTokenWithPrivilegeUrl(URLS.accountStatementListApi, apiKey).subscribe((result) => {
        console.log("brand category Acc Statement Api Result==", result);
        if (result.success == 1 || result.success == '1') {
          this.Alldata.history='';
          this.location.back();
          this.todayAccStatementRespo=result;
          this.Alldata.history=this.todayAccStatementRespo.history;
          this.todayBrandDetail=result.brand_detail;
      
          if(this.tabType=="Today"){
            console.log("this.tabType1==", this.tabType);
            this.todayListResult = result.history;
          }else if(this.tabType="All" || this.creditType){
            console.log("this.tabType2==", this.tabType);
            console.log("this.creditType==", this.creditType);
            this.allListResult = result.history;
            this.filterArray=result.filter_arr;
            this.showFilterDiv = false;
            for(let i=0; i<this.filterArray.data.length; i++){
              console.log("this.filterArray.data.length==", this.filterArray.data.length);
              if(this.filterArray.data[i].value==this.filterArray.data[i].checked){
                this.showCheckRadio=this.filterArray.data[i].checked; 
                console.log("this.showCheckRadio==", this.showCheckRadio);
              }
            }
          }
          this.todayListResult= this.todayListResult.concat(result.data);
          // }
          if(this.myinfiniteScrollCall==true){
            this.myInfiniteScroll.target.complete();
            this.myinfiniteScrollCall=false;
          }
          console.log("thoughtOftheDayApi List data1==", this.todayListResult);
          this.errorMessage='';
          console.log("thoughtOftheDayApi List data2==", this.errorMessage);
          this.errorImage=result.error_image;
        }else{
          this.errorMessage = result.message;
          // this.errorImage=result.error_image;
          if(this.myinfiniteScrollCall==true){
            this.myInfiniteScroll.target.complete();
            this.myinfiniteScrollCall=false;
          }
        }
      }, (err)=>{
        console.log("last array of account statement==", err);
        this.apiservices.showToastMessage(JSON.stringify(err), 'top', 3000, 'redBg');
      });
    });
  }


}
