import { Component, OnInit, NgZone } from '@angular/core';
import { ModalController } from '@ionic/angular';
import{RedeemotpPage} from '../redeemotp/redeemotp.page';
import { ApiService } from 'src/app/provider/api.service';
import { DataTransferService } from 'src/app/services/data-transfer.service';
import { URLS } from 'src/assets/constant';
import { Router } from '@angular/router';

@Component({
  selector: 'app-buyitem',
  templateUrl: './buyitem.page.html',
  styleUrls: ['./buyitem.page.scss'],
})
export class BuyitemPage implements OnInit {
num:number=1;
redeem_for:any;
addres:any;
item_details:any;
addres_id:any;
loginPageData:any;
temparray:any;
quantity:any;
cart_details:any;
cart_detail:any =[];
cart_req:any;
  msg: any;
  constructor(public modalCtrl: ModalController,private sendData: DataTransferService, public route: Router, public apiService:ApiService, private zone:NgZone) {
   
   }
   ionViewWillEnter(){
    this.redeem_for = this.sendData.redeem_for;
    this.item_details = this.sendData.itemDetails;
   // this.quantity = this.sendData.count;
  
    console.log('val', this.item_details);
  //  this.cart_details = this.sendData.cartDetails;
    this.cart_req = this.sendData.cart_request;
    this.showAddress();
    this.buyitem(this.item_details);
   // this.cart_details = this.sendData.cartDetails;
   // this.itemDetailsShow();
   }
  ngOnInit() {
    // this.showAddress();
    // this.buyitem(this.item_details);
  }
  minus(item){
    if(item.quantity!=0){
      item.quantity = JSON.parse(item.quantity);
      item.quantity=item.quantity-1;
      this.cart_req = "buy";
    //  this.buyitem(item);
    }
   
  }
  plus(item){
    // item.quantity = parseInt(item.quantity);
    item.quantity= parseInt(item.quantity)+1;
    this.cart_req = "buy";
  //  this.buyitem(item);
   
  }

buyitem(item){ 
  this.apiService.presentLoadingDefault();
  this.zone.run(async () => {
    let apiKey = {
      "request_page":"dealer",
      "redeem_for":this.redeem_for,
      "cart_request":this.cart_req,
      "product_arr": [
        {
            "product_id":item.product_id,
            "count":item.quantity
        }]
    }
    console.log("item.product_id ,item.quantity ", item.quantity, item.quantity)
    
    this.apiService.apiCallWithLoginToken(URLS.CartUrl, apiKey).subscribe((result) => {
      this.apiService.presentLoadingClose();
      //this.temparray = result.data;
      if (result.success == 1) {
        this.cart_details=result.data;
      //  // this.serverData=result.data;
      //  this.sendData.itemDetails = this.item_details;
      //  this.sendData.cartDetails = result.data
      //  this.sendData.page_request_type = 'buy';
      // this.router.navigate(['/buyitem']);
      this.msg ='';
      } else {
        this.msg = result.message;
        // this.apiService.showToastMessage(result.message, 'top', 3000, 'redBg');
      }
      
    }, err => {
      this.apiService.presentLoadingClose();
      this.apiService.showToastMessage(JSON.stringify(err), 'top', 3000, 'redBg');
      
    });
     
    });
  }
  itemDetailsShow(){
    
    this.zone.run(async () => {
      let apiKey = {
        "request_page":"dealer",
        "redeem_for":this.redeem_for,
        "product_id":this.item_details.auto_id,
        "page_request_type":this.sendData.page_request_type
      }
      
      this.apiService.apiCallWithLoginToken(URLS.ProductDetailUrl, apiKey).subscribe((result) => {
        
        this.temparray = result.data;
        if (result.success == 1) {
         // this.serverData=result.data;
        
        } else {
          this.apiService.showToastMessage(result.message, 'top', 3000, 'redBg');
        }
        
      }, err => {
        this.apiService.showToastMessage(JSON.stringify(err), 'top', 3000, 'redBg');
       
      });
     
  
    });
   }
 modalcall(){
  this.sendData.cartDetails =  this.cart_details;
  // this.cart_detail = [];
  // for(let i = 0; i<this.cart_details.length; i++){
  //   //if(this.cart_details[i].quantity != 0){
  //     // this.cart_detail.push(this.cart_details[i]);
  //     this.cart_detail = this.cart_details[i];
    
    

  // }
  // let item = [{
  //   "product_id":this.cart_detail[i].product_id,
  //   "count":this.cart_detail[i].quantity
  // }];
  //this.buyitem(item);
  
 // this.buyitem();
  console.log(" this.cart_details" ,  this.cart_detail);
  this.sendData.address_id = this.addres.data.data[0].auto_id;
  this.callModal();
}
async callModal(){
  const modal = await this.modalCtrl.create({
    component: RedeemotpPage,
    cssClass: 'my-custom-class'
  });

  modal.onDidDismiss().then((dataReturned) => {
    if (dataReturned !== null) {
     
    }
    else{
      
    }
  });
  return await modal.present();
}
showAddress(){
  this.apiService.presentLoadingDefault();
  this.zone.run(()=>{
    let apiKey = {
      "address_fetch_type":"deliver",
      "redeem_for":this.redeem_for,
      "request_page":"dealer",
    }
    this.apiService.apiCallWithLoginToken(URLS.AddressUrl,apiKey).subscribe((result) =>{
      console.log("AddressUrl: ", result);
      this.apiService.presentLoadingClose();
      this.addres = result;
      if(result.success==1){
        
      }else {

      }
    },err=>{
      this.apiService.presentLoadingClose();
      this.apiService.showToastMessage(JSON.stringify(err), 'top', 3000, 'redBg');
    });
  });
}
changeAddress(){
  this.route.navigate(['./change-address']);
}
doneUpdate(){
  this.cart_detail = [];
  for(let i = 0; i<this.cart_details.length; i++){
    this.cart_details[i]['count'] = this.cart_details[i].quantity;
   // if(this.cart_details[i].quantity != 0){
       this.cart_detail.push(this.cart_details[i]);
      //this.cart_detail = this.cart_details[i];
    
    

  }
  this.zone.run(async () => {
    let apiKey = {
      "request_page":"dealer",
      "redeem_for":this.redeem_for,
      "cart_request":this.cart_req,
      "product_arr": this.cart_detail
    }
    console.log("apikey : ", apiKey)
    console.log("product_arr:", this.cart_detail)
    
    this.apiService.apiCallWithLoginToken(URLS.CartUrl, apiKey).subscribe((result) => {
     
      //this.temparray = result.data;
      if (result.success == 1) {
        this.cart_details=result.data;
      //  // this.serverData=result.data;
      //  this.sendData.itemDetails = this.item_details;
      //  this.sendData.cartDetails = result.data
      //  this.sendData.page_request_type = 'buy';
      // this.router.navigate(['/buyitem']);
      
      } else {
        this.apiService.showToastMessage(result.message, 'top', 3000, 'redBg');
      }
      
    }, err => {
      this.apiService.showToastMessage(JSON.stringify(err), 'top', 3000, 'redBg');
      
    });
     
    });
}
}
