import { Component, OnInit, NgZone } from '@angular/core';
import { ApiService } from 'src/app/provider/api.service';
import { DataTransferService } from 'src/app/services/data-transfer.service';
import { URLS } from 'src/assets/constant';
import { Router } from '@angular/router';

@Component({
  selector: 'app-purchasehistory',
  templateUrl: './purchasehistory.page.html',
  styleUrls: ['./purchasehistory.page.scss'],
})
export class PurchasehistoryPage implements OnInit {
  arrr:any=[];
  constructor(private router:Router, private sendData: DataTransferService, public route: Router, public apiService:ApiService, private zone:NgZone) {

    // this.arrr=[{"image":'assets/Other Icons/powerbank.png',"itemname":'iron1',"forpoints":'1000',"quantity":'2',"status":'pending',"orderid":'asdf4'},
    // {"image":'assets/Other Icons/powerbank.png',"itemname":'iron1',"forpoints":'1000',"quantity":'2',"status":'deleverd',"orderid":'asdf4'},
    // {"image":'assets/Other Icons/powerbank.png',"itemname":'iron1',"forpoints":'1000',"quantity":'2',"status":'Accepted',"orderid":'asdf4'}]
   }

  ngOnInit() {
    this.purchaseHIst();
  }
  modalcall(item){
    this.sendData.itemDetails = item; 
    this.sendData.redeem_for = 'self';
    this.sendData.page_request_type = 'detail';
    this.router.navigate(['./itemdetail']);
  }
  purchaseHIst(){
    this.apiService.presentLoadingDefault();
    this.zone.run(async () => {
      let apiKey = {
        "value":""
      }
    
      this.apiService.apiCallWithLoginToken(URLS.PurchaseHistoryUrl, apiKey).subscribe((result) => {
        this.apiService.presentLoadingClose();
        this.arrr = result.data;
        if(result.success == 1 || result.success == '1'){
         
        }
        else{
          
        }
      })
    });
  }
}
