import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { HttpClient, HttpEvent, HttpEventType } from '@angular/common/http';
import { ApiService } from 'src/app/provider/api.service';
import { URLS } from 'src/assets/constant';
import { Platform } from '@ionic/angular';
@Component({
  selector: 'app-model-camera',
  templateUrl: './model-camera.page.html',
  styleUrls: ['./model-camera.page.scss'],
})
export class ModelCameraPage implements OnInit {
  files:any=[];
  userImage: string | ArrayBuffer;
  currentObj: any;
  RegistrationData:any;
  RequestPage:any;
  RequestFor:any;
  flag: string;
  constructor(public modalController: ModalController,public apiServices:ApiService ,public navParam:NavParams, public platform:Platform) {
    this.RegistrationData=this.navParam.data.data;
    console.log(" this.RegistrationData",this.RegistrationData);
    console.log(" this.RegistrationData",this.navParam.data.data);
    if(this.RegistrationData!=undefined || this.RegistrationData!=''){
      if(this.RegistrationData.nulldata){
        this.flag=this.RegistrationData.flag;
      }else{
        this.flag="5";
      }
      console.log("1");
      console.log(" this.RegistrationData",this.navParam.data.data)
      this.RequestFor=this.RegistrationData.requestFor;
      this.RequestPage=this.RegistrationData.requestPage;
      
    }else{
      console.log("2");
      this.RequestFor='';
      this.RequestPage='';
      
    }
    console.log('this registrationData from profile upload page',this.RegistrationData);
   }

  ngOnInit() {
  }
  close(){
    this.modalController.dismiss({
      'dismissed': true
    });
  }
  captureImg(event) {
    this.apiServices.presentLoadingDefault();
    console.log('event1==>', event);
    var formData = new FormData();
    if(event.target.files){
      const file = event.target.files[0];
      formData.append('file', file);
      formData.append('flag_type',this.flag);
      formData.append('media_type', "1");
      formData.append('request_for',this.RequestFor);
      formData.append('request_page', this.RequestPage);
      console.log('formData==>', formData);
      this.apiServices.mediaFileUpload(URLS.imageUploadUrl, formData).subscribe((event: HttpEvent<any>) => {
       
        console.log('Multi File upload res==> ', JSON.stringify(event));
        switch (event.type) {
          case HttpEventType.Sent:
            console.log('Request has been made!');
            break;
          case HttpEventType.ResponseHeader:
            console.log('Response header has been received!');
            break;
          case HttpEventType.Response:
            let result=event.body    
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
          console.log(reader.result);
          formData.append("file", this.files);
         console.log('this.currentObj==>', this.currentObj);
        // this.currentObj.answer= reader.result;
        this.apiServices.presentLoadingClose();
         this.modalController.dismiss({
          'dismissed': true,
          // 'data':reader.result
          'data':result.data
        });
      };
    }
    },err=>{
      this.apiServices.presentLoadingClose();
      this.apiServices.showToastMessage(JSON.stringify(err),'top',3000,'redBg');
      // this.dismissLoading();
    });
  }

    }
  

}
